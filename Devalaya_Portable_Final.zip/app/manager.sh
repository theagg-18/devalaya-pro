#!/bin/bash
python3 manager.py
