@echo off
set "DIST_DIR=%~dp0"
set "PYTHON_EXE=%DIST_DIR%python\python.exe"
set "APP_DIR=%DIST_DIR%app"

echo Starting Devalaya Billing System...
echo Python: %PYTHON_EXE%
echo App: %APP_DIR%

cd /d "%APP_DIR%"
"%PYTHON_EXE%" run_prod.py
pause
